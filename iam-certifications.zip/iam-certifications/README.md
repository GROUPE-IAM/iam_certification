# IAM Certifications

Plugin WordPress de gestion du **catalogue de formations** du Groupe IAM — **certificats professionnels** (parcours de 6 à 12 semaines) et **séminaires intensifs** (3 jours en présentiel ou intra) : custom post type, taxonomies, champs, shortcode de liste, page de détail (landing) et **intégration avec le plugin IAM Leads**.

- **Version** : 1.1.0
- **Prérequis** : WordPress 6.0+, PHP 7.4+
- **Optionnel** : plugin **IAM Leads** (pour le formulaire de candidature embarqué)

---

## Installation

1. Copier le dossier `iam-certifications` dans `wp-content/plugins/`.
2. Dans **Extensions**, activer « IAM Certifications ».
3. Au premier chargement de l'admin, le plugin **crée automatiquement les 8 certifications** du site (sans prix ni partenaire) et, si IAM Leads est actif, **le formulaire pro multi-étapes**.

> Le seed est **idempotent** : il ne s'exécute qu'une fois (protégé par des options). Si IAM Leads est activé *après* IAM Certifications, le formulaire est créé au chargement d'admin suivant.

---

## Utilisation

### Afficher la liste — shortcode `[iam_certifications]`

À coller dans un widget *Shortcode* d'Elementor ou dans une page.

| Attribut | Rôle | Défaut |
|---|---|---|
| `type` | `certificat` ou `seminaire` (vide = tous) | — |
| `columns` | colonnes grand écran (1–4) | `3` |
| `domaine` | slug(s) de domaine, séparés par des virgules | — |
| `outil` | slug(s) d'outil | — |
| `featured` | `true` = mises en avant uniquement | — |
| `limit` | nombre maximum | `-1` |
| `max_tools` | outils affichés avant « +N » | `6` |
| `group_by_domaine` | `true` = sections titrées par domaine | — |
| `filters` | `true` = barre de filtre cliquable | — |

Exemples :
```
[iam_certifications columns="3" filters="true"]
[iam_certifications group_by_domaine="true"]
[iam_certifications domaine="marketing-digital" columns="4"]
[iam_certifications featured="true" limit="3"]
[iam_certifications type="seminaire" group_by_domaine="true"]
[iam_certifications type="certificat" filters="true"]
```

### Deux types de formation

Chaque formation est soit un **certificat**, soit un **séminaire**. Le type se choisit en
première étape de l'assistant (cartes de choix) ; les champs, les libellés et la page de
détail s'adaptent. Les fiches créées avant la v1.2 sont des certificats.

| | Certificat professionnel | Séminaire intensif |
|---|---|---|
| Chiffres clés du hero | heures, semaines, modules, leçons | jours, heures, % de pratique, participants max |
| Programme | **frise de modules** qui se remplit au scroll, leçons dépliables, projet final mis en avant | **jour par jour** (J1, J2, J3…), matin / après-midi |
| Format | format, durée, rythme, niveau | jauge animée « % de pratique », groupe, horaires, suivi eLearning, infos pratiques |
| Fin de parcours | débouchés (métiers) + certificat délivré | livrables + attestation de réussite |
| Spécifique | — | **sessions datées** en cartes « billet » (+ carte intra) ; la session cliquée est transmise avec le lead |
| Bouton principal | « Candidater » | « Réserver ma place » |

### Page de détail

Chaque formation a sa page (`/certifications/<slug>/`) :

1. **Hero** plein écran : fil d'Ariane, type, titre révélé mot à mot (un titre « X — sous-titre »
   est séparé en deux), accroche, boutons, fiche « En bref » en verre dépoli (inclinaison 3D au
   survol), chiffres clés avec compteurs animés.
2. **Bandeau d'outils** défilant (taxonomie Outils).
3. **Navigation collante** : section active surlignée, barre de progression de lecture,
   bouton d'action affiché une fois la barre collée.
4. Sections (masquées si vides) : objectifs en cartes numérotées, programme, format, pour qui
   (public en puces + prérequis), sessions, débouchés, certificat / livrables (diplôme 3D).
5. Téléchargements, **candidature** (formulaire IAM Leads + contact direct), formations proches.
6. Mobile : barre d'action flottante en bas d'écran.

Animations GSAP + ScrollTrigger (bundlés en local). Avec `prefers-reduced-motion` ou sans
JavaScript, tout le contenu reste visible et statique.

### Interface d'administration dédiée

Menu **Formations** : **Catalogue** (liste filtrable Tout / Certificats / Séminaires, boutons
« Nouveau certificat » et « Nouveau séminaire »), **Ajouter**, **Domaines**, **Outils**.

L'assistant de saisie (inspiré des formulaires de création de ticket-place) compte 6 étapes,
avec stepper, barre de progression et « Ensuite : … » :

1. **Identité** : type (cartes), titre, accroche, domaine / collection, visuel (zone de dépôt).
2. **Format & durée** / **Format & sessions** : chiffres clés ; pour un séminaire, horaires, suivi, sessions (« dates | lieu », une par ligne) et infos pratiques.
3. **Contenu & public** : objectifs, public, prérequis, puis débouchés + projet final (certificat) ou livrables (séminaire), évaluation, coût.
4. **Modules** (répéteur titre + leçons) ou **Jour par jour** (répéteur J1, J2… matin / après-midi, 3 jours préparés).
5. **Médias & liens** : vidéo, image secondaire, brochure, dossier / bulletin, rendez-vous, texte du bouton.
6. **Publication** : outils, formulaire IAM Leads, mise en avant, check-list de vérification.

Seul le titre est obligatoire. « Brouillon » enregistre à tout moment ; après
enregistrement, l'assistant rouvre l'étape où l'on était.

---

## Intégration IAM Leads

- La landing embarque le formulaire via `[iam_form id="X"]`. L'ID vient du réglage
  de la certification, sinon du **formulaire « certifications » par défaut** créé au seed.
- Le formulaire par défaut est **multi-étapes**, pensé pour les professionnels :
  1. Profil professionnel (nom, poste, entreprise, secteur, taille)
  2. Projet (objectif, financement, disponibilité)
  3. Coordonnées (e-mail pro, téléphone, contact préféré, consentement)
- Un **champ caché `certification`** (mappé sur la colonne `programme` d'IAM Leads) est
  rempli automatiquement par la landing : chaque lead est ainsi rattaché à SA certification
  (visible dans le dashboard, l'export et l'e-mail de notification). En complément,
  `utm_campaign` reçoit le slug **s'il est vide** (ne remplace jamais une vraie campagne).
- Au seed, **banel@groupeiam.com** est ajouté aux destinataires internes d'IAM Leads
  (Réglages → Destinataires internes), sans écraser les adresses existantes.

> ⚠️ Pour que les e-mails partent réellement, le **SMTP doit être configuré** dans
> IAM Leads → Réglages (l'image Docker WordPress n'a pas de service d'envoi). Sans SMTP,
> **les leads restent enregistrés en base** et visibles dans le dashboard.

Si IAM Leads est absent, la landing affiche un **repli contact direct** (e-mail + téléphone).

### Contact

Par défaut : **Banel — banel@groupeiam.com — +221 77 714 39 91**. Personnalisable via le filtre :
```php
add_filter( 'iam_cert_contact', function ( $c ) {
	$c['email'] = 'autre@groupeiam.com';
	return $c;
} );
```

---

## Surcharge des templates par le thème

Copier un template dans le thème pour le personnaliser :

- `votre-theme/iam-certifications/card.php` (carte de liste)
- `votre-theme/single-certification.php` *(ou)* `votre-theme/iam-certifications/single-certification.php` (page de détail)

---

## Contenu pré-rempli

**v1.2** ajoute les **8 séminaires** du catalogue 2026-2027 (collections « Talents × IA » et
« Marketing Digital & IA » : programme J1–J3, objectifs, public, prérequis, livrables) et le
certificat **CEDLA** (`includes/data/seminaires-seed.php`), sans prix ni partenaire. Les
sessions ne sont pas datées (à saisir dans l'admin). Import idempotent (option
`iam_cert_seed_v12`) ; les fiches existantes reçoivent le type « certificat ».

Les 8 certifications sont **pré-remplies à partir du contenu réel** des fiches
`/certification/` de groupeiam.com (accroche, modules, leçons, niveau, format, public,
prérequis, évaluation, outils), **sans le prix ni le partenaire**.

À faire après activation :
- **Ajouter les images** mises en avant (le seed n'importe pas les visuels).
- Relire les textes dans l'admin si besoin.

> Note : sur le site, les slugs d'URL des fiches sont mélangés, mais le contenu correspond
> bien aux 8 formations ; le plugin les recrée avec des slugs propres.

---

## Structure

```
iam-certifications/
├── iam-certifications.php          Amorçage, constantes, activation/flush
├── uninstall.php                   Nettoyage des options (conserve les données)
├── includes/
│   ├── iam-cert-helpers.php        Templates surchargeables, données, modules, contact, rendu formulaire
│   ├── class-iam-cpt.php           CPT « certification »
│   ├── class-iam-taxonomies.php    Taxonomies domaine + outil
│   ├── class-iam-metaboxes.php     Metabox : infos, programme (répéteur modules), formulaire
│   ├── class-iam-admin.php         Colonnes, tri, filtre par domaine
│   ├── class-iam-assets.php        Chargement CSS/JS
│   ├── class-iam-shortcode.php     [iam_certifications]
│   ├── class-iam-template.php      Route de la page de détail
│   ├── class-iam-seeder.php        Seed : 8 certifs + formulaire pro
│   └── data/
│       └── certifications-seed.php Données scrapées des 8 fiches
├── templates/
│   ├── card.php                    Carte de liste
│   └── single-certification.php    Page de détail (landing)
└── assets/
    ├── css/iam-front.css           Design --ckd-* responsive
    ├── css/iam-admin.css
    ├── js/iam-front.js             Filtre + pont formulaire
    └── js/iam-admin.js             Répéteur de modules
```

---

## Journal des versions

### 1.3.0
- Page de détail : direction « sobre + temps forts verts » (hero, programme, sessions / débouchés, candidature en vert ; accent `#EDA900`), formulaire IAM Leads aux couleurs IAM (surcharge CSS, IAM Leads inchangé), logo du Groupe IAM sur le diplôme (filtre `iam_cert_logo_url`).
- Admin : écrans centrés, écrans maison **Domaines** et **Outils** (les écrans natifs redirigent), champs obligatoires pour publier (contrôle navigateur + serveur ; une fiche déjà en ligne n'est jamais dépubliée).
- Données : compléments tirés des catalogues PDF (`includes/data/complements-v13.php`, option `iam_cert_seed_v13`) — objectifs et projet final des 9 certificats, rythme, corrections Knowledge Management RH (format atelier, mention tarifaire retirée), ADAPT-IA (blended, 10 à 12 semaines). Non destructif : seuls les champs vides ou encore identiques à l'import d'origine sont touchés.

### 1.2.0
- Deux types de formation : **certificat** et **séminaire** (méta `_iam_type`), champs propres à chaque type.
- Nouvelle page de détail (hero animé, compteurs, frise de modules, programme jour par jour, sessions, diplôme 3D, navigation collante).
- Nouvel assistant d'administration en 6 étapes et nouvelle liste du catalogue.
- Import des 8 séminaires et du certificat CEDLA ; shortcode : attribut `type`.

### 1.1.0
- Nouvelle page de détail en bandes pleine largeur (hero sur image, blocs dépliables colorés, bande débouchés, bande modalités, bandeau de téléchargement).
- Nouveaux champs : objectifs, débouchés, rythme, coût et scolarité, vidéo, image secondaire, brochure, dossier de candidature, lien de RDV.
- Fenêtre vidéo (chargement au clic), barre « Candidater » sur mobile.
- Admin : nouvelle étape « Médias & liens », sélecteur Médiathèque pour les fichiers, lien « Voir la page ».
- Texte du bouton par défaut : « Candidater ».
- Animations : une seule entrée orchestrée sur le hero (suppression des apparitions à chaque section).

### 1.0.0
- Version initiale.
